<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SbuNames extends Model
{
    //
}
