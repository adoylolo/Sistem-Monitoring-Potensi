<?php $__env->startSection('title', 'Data Potensi | Detail'); ?>
<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $potencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">

            <div class="col-xl-8">
                <div class="card shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h4 class="col-12 mb-0 text-primary"><?php echo e(__('Detail Potensi')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php echo e(csrf_field()); ?>

                        <div class="table-responsive">
                                <table class="table table-hover">
                                    <tbody>
                                    <tr>
                                        <td>SBU Region</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->sbu_region); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Nama Sales</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->nama_sales); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Nama Pelanggan</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->nama_pelanggan); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Segmen Service</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->segmen_service); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Service</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->jenis_service); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Kategori Service</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->kategori_service); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Kapasitas </td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->kapasitas); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Satuan</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->satuan_kapasitas); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Action Plan</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->update_action_plan); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Kantor</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->nama_kantor); ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4">
                <div class="card shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h4 class="col-12 mb-0 text-primary"><?php echo e(__('Detail Aktivitas')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php echo e(csrf_field()); ?>

                         <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                    <tr>
                                        <td>Target Quote</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->target_quote); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Real Quote</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->real_quote); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Quote Late</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->quote_late); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Target Nego</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->target_nego); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Real Nego</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->real_nego); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Nego Late</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->nego_late); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Target PO</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->target_po); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Real PO</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->real_po); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>PO Late</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->po_late); ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                    </div>
                </div>
            </div>

        </div>

                <div class="row mt-4">

            <div class="col-xl-12">
                <div class="card shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h4 class="col-12 mb-0 text-primary"><?php echo e(__('Detail Revenue')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php echo e(csrf_field()); ?>

                            <div class="card">
                                <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                    <tr>
                                        <td>Target Aktivasi (Bulan Aktivasi)</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->target_aktivasi_bln); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Instalasi OTC</td>
                                        <td>:</td>
                                        <td><strong>Rp. <?php echo number_format($data->instalasi_otc,0,',','.'); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Sewa (Bulan)</td>
                                        <td>:</td>
                                        <td><strong>Rp. <?php echo number_format($data->sewa_bln,0,',','.'); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>QTY</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->qty); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Revenue Formula</td>
                                        <td>:</td>
                                        <td><strong>Rp. <?php echo number_format($data->revenue_formula,0,',','.'); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Warna Status Potensi</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->warna_potensi); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Anggaran pra Penjualan</td>
                                        <td>:</td>
                                        <td><strong>Rp. <?php echo e($data->anggaran_pra_penjualan); ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">

            <div class="col-xl-7">
                <div class="card shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h4 class="col-12 mb-0 text-primary"><?php echo e(__('Detail Lokasi')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php echo e(csrf_field()); ?>

                                <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                    <tr>
                                    <td>Originating</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->originating); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Terminating</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->terminating); ?></strong></td>
                                    </tr>
                                    <?php $__currentLoopData = $datax; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>SBU Originating</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data1->sbu_originating); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>SBU Terminating</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data1->sbu_terminating); ?></strong></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-5">
                <div class="card shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h4 class="col-12 mb-0 text-primary"><?php echo e(__('Detail Pelanggan')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php echo e(csrf_field()); ?>

                            <div class="card">
                                <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                    <tr>
                                        <td>Status Pelanggan</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->status_pelanggan); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Segmen Pelanggan</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->jenis_pelanggan); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Kategori Pelanggan</td>
                                        <td>:</td>
                                        <td><strong><?php echo e($data->kategori_pelanggan); ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            </div>
                    </div>
                </div>
            </div>

        </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_1\resources\views/pages/detail_potensi.blade.php ENDPATH**/ ?>