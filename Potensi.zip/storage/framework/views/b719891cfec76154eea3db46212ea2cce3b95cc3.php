<footer class="footer">
  <div class="container-fluid clearfix">
    <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2020 <a href="" target="_blank">Icon+</a>. All rights reserved.</span>
    </span>
  </div>
</footer><?php /**PATH C:\xampp\htdocs\Project_1\resources\views/layout/footer.blade.php ENDPATH**/ ?>