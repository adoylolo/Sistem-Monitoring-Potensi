<?php $__env->startSection('title', 'Login ICON+'); ?>
<?php $__env->startSection('content'); ?>

<div class="content-wrapper d-flex align-items-center justify-content-center auth theme-one" style="background-image: url(<?php echo e(url('assets/images/auth/login_1.jpg')); ?>); background-size: cover;">
  <div class="row w-100">

    <div class="container mt--8 pb-5">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <div class="card">
                    <div class="card-body">
						<div class="form-group">
							<div class="text-center"><h2 class="text-primary"><?php echo e(__('Selamat Datang')); ?></h2></div>
						</div>
						<br>
						<div class="form-group">
							<a href="<?php echo e(route('admin.login')); ?>" class="btn btn-block btn-outline-primary btn-rounded btn-lg">Login Admin</a>		
						</div>
						<div class="form-group">
							<a href="<?php echo e(route('sales.login')); ?>" class="btn btn-block btn-outline-primary btn-rounded btn-lg">Login Sales</a>		
						</div>
						<br>

                    </div>
                </div>
            </div>
        </div>
    </div>

  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master-mini', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_1\resources\views/welcome.blade.php ENDPATH**/ ?>