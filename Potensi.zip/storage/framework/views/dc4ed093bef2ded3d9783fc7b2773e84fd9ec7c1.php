<?php $__env->startSection('title', 'Login ICON+'.' | '.ucwords($url)); ?>
<?php $__env->startSection('content'); ?>

<div class="content-wrapper d-flex align-items-center justify-content-center auth theme-one" style="background-image: url(<?php echo e(url('assets/images/auth/login_1.jpg')); ?>); background-size: cover;">
  <div class="row w-100">

    <div class="container mt--8 pb-5">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <div class="card shadow border-0">
                    <div class="card-body px-lg-8 py-lg-8">
                        <div class="card-header bg-white"><h3 class="text-primary"> <?php echo e(__('Login')); ?> <?php echo e(isset($url) ? ucwords($url) : ""); ?> </h3></div>
                        <?php if(isset($url)): ?>
                            <form method="POST" action='<?php echo e(url("login/$url")); ?>' aria-label="<?php echo e(__('Login')); ?>">
                                <?php else: ?>
                                    <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                                        <?php endif; ?>
                                        <?php echo csrf_field(); ?>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="alert alert-danger alert-block">
                                                <button type="button" class="close" data-dismiss="alert">×</button>
                                                <strong><?php echo e($error); ?></strong>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?> mb-3">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                    </div>
                                    <input class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email')); ?>" type="email" name="email" value="<?php echo e(old('email')); ?>" value="admin@argon.com" required autofocus>
                                </div>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                    </div>
                                    <input class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Password')); ?>" type="password" required>
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="custom-control custom-control-alternative custom-checkbox">
                                <input class="custom-control-input" name="remember" id="customCheckLogin" type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <label class="custom-control-label" for="customCheckLogin">
                                    <span class="text-muted"><?php echo e(__('Remember me')); ?></span>
                                </label>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-lg my-4"><?php echo e(__('Sign in')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-6">
                        <?php if(Route::has('password.request')): ?>
                            <a href="<?php echo e(route('password.request')); ?>" class="text-light">
                                <small><?php echo e(__('Forgot password?')); ?></small>
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="col-6 text-right">
                        <a href="<?php echo e(route('register')); ?>" class="text-light">
                            <small><?php echo e(__('Create new account')); ?></small>
                        </a>
                    </div>
                </div>

                <div class="row col-lg-12">
                <div class="card-body bg-white">
                    <div class="text-center text-danger"><h5>Informasi Login Admin dan Sales</h5></div>
                    <table class="table table-responsive table-condensed table-hover">
                      <tr>
                        <td colspan="3" class="text-primary"><b>Admin</b></td>
                      </tr>
                      <tr>
                        <td>Username</td>
                        <td>:</td>
                        <td class="text-success">admin@admin.com</td>
                      </tr>
                      <tr>
                        <td>Password</td>
                        <td>:</td>
                        <td class="text-success">tester123</td>
                      </tr>
                      <tr>
                        <td colspan="3" class="text-primary"><b>Sales</b></td>
                      </tr>
                      <tr>
                        <td>Username</td>
                        <td>:</td>
                        <td class="text-success">farhaan.sales@sales.com</td>
                      </tr>
                      <tr>
                        <td>Password</td>
                        <td>:</td>
                        <td class="text-success">tester123</td>
                      </tr>
                    </table>
                </div>
                </div>

            </div>
        </div>
    </div>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master-mini', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_1\resources\views/auth/login.blade.php ENDPATH**/ ?>