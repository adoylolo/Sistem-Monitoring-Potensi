<!DOCTYPE html>
<html>
<head>
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- CSRF Token -->
  <meta name="_token" content="<?php echo e(csrf_token()); ?>">
  
  <link rel="shortcut icon" href="<?php echo e(asset('/favicon.ico')); ?>">

  <!-- plugin css -->

    <link href="<?php echo e(asset('assets')); ?>/plugins/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet">
    <link href="<?php echo e(asset('assets')); ?>/plugins/@mdi/font/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css" rel="stylesheet">
	
  <!-- end plugin css -->

  <?php echo $__env->yieldPushContent('plugin-styles'); ?>

  <!-- common css -->
   <link href="<?php echo e(asset('css')); ?>/app.css" rel="stylesheet">
  <!-- end common css -->


  <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body data-base-url="<?php echo e(url('/')); ?>">

  <div class="container-scroller" id="app">
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">
	<?php if(auth()->guard("admin")->check()): ?>
		<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>

	<?php if(auth()->guard("sales")->check()): ?>
		<?php echo $__env->make('layout.sidebar-sales', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>

  <!-- base js -->
  <script src="<?php echo e(asset('js')); ?>/app.js"></script>
  <script src="<?php echo e(asset('assets')); ?>/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
  <!-- end base js -->

  <!-- plugin js -->
  <?php echo $__env->yieldPushContent('plugin-scripts'); ?>
  <script src="https://code.jquery.com/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
  <script>
		function hanyaAngka(evt) {
		  var charCode = (evt.which) ? evt.which : event.keyCode
		   if (charCode > 31 && (charCode < 48 || charCode > 57))

		    return false;
		  return true;
		}
  </script>
  <script>
		  function ConfirmDelete() {
			  if(!confirm("Yakin akan menghapus data ini?"))
			  event.preventDefault();
		  }
  </script>
  <!-- end plugin js -->

  <!-- common js -->
    <script src="<?php echo e(asset('assets')); ?>/js/off-canvas.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/hoverable-collapse.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/misc.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/settings.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/todolist.js"></script>
  <!-- end common js -->


  <?php echo $__env->yieldPushContent('custom-scripts'); ?>
  
</body>
</html><?php /**PATH C:\xampp\htdocs\Project_1\resources\views/layout/master.blade.php ENDPATH**/ ?>