<nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
  <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
    <a class="navbar-brand brand-logo" href="<?php echo e(url('/')); ?>">
      <img src="<?php echo e(url('assets/images/icon.png')); ?>" alt="logo" /> </a>
    <a class="navbar-brand brand-logo-mini" href="<?php echo e(url('/')); ?>">
      <img src="<?php echo e(url('assets/images/iconplus-mini.png')); ?>" width="100%" alt="logo" /> </a>
  </div>
  <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
      <span class="mdi mdi-menu"></span>
    </button>
    <ul class="navbar-nav navbar-nav-left header-links">
      <li class="nav-item dropdown d-none d-lg-flex">
        <a class="nav-link dropdown-toggle px-0 ml-3" id="quickDropdown" href="#" data-toggle="dropdown" aria-expanded="false">  <i class="mdi mdi-flash"></i>Akses Cepat </a>
        <div class="dropdown-menu dropdown-menu-right navbar-dropdown pt-3" aria-labelledby="quickDropdown">
		<?php if(auth()->guard("admin")->check()): ?>
          <a href="<?php echo e(route('create.step.one')); ?>" class="dropdown-item"><i class="mdi mdi-plus"></i>Tambah Potensi</a>
          <a href="<?php echo e(route('admin.customer_add')); ?>" class="dropdown-item"><i class="mdi mdi-plus"></i>Tambah Customer</a>
		<?php endif; ?>
		<?php if(auth()->guard("sales")->check()): ?>
          <a href="<?php echo e(route('sales.create.step.one')); ?>" class="dropdown-item"><i class="mdi mdi-plus"></i>Tambah Potensi</a>
          <a href="<?php echo e(route('sales.customer_tambah')); ?>" class="dropdown-item"><i class="mdi mdi-plus"></i>Tambah Customer</a>
		<?php endif; ?>
        </div>
      </li>
    </ul>
    <ul class="navbar-nav navbar-nav-right">
      <li class="nav-item dropdown">
        <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
          <i class="mdi mdi-bell-outline"></i>
          <span class="count bg-danger">4</span>
        </a>
        <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list pb-0" aria-labelledby="notificationDropdown">
          <a class="dropdown-item py-3 border-bottom">
            <p class="mb-0 font-weight-medium float-left">4 new notifications </p>
            <span class="badge badge-pill badge-primary float-right">View all</span>
          </a>
          <a class="dropdown-item preview-item py-3">
            <div class="preview-thumbnail">
              <i class="mdi mdi-alert m-auto text-primary"></i>
            </div>
            <div class="preview-item-content">
              <h6 class="preview-subject font-weight-normal text-dark mb-1">Application Error</h6>
              <p class="font-weight-light small-text mb-0"> Just now </p>
            </div>
          </a>
          <a class="dropdown-item preview-item py-3">
            <div class="preview-thumbnail">
              <i class="mdi mdi-settings m-auto text-primary"></i>
            </div>
            <div class="preview-item-content">
              <h6 class="preview-subject font-weight-normal text-dark mb-1">Settings</h6>
              <p class="font-weight-light small-text mb-0"> Private message </p>
            </div>
          </a>
          <a class="dropdown-item preview-item py-3">
            <div class="preview-thumbnail">
              <i class="mdi mdi-airballoon m-auto text-primary"></i>
            </div>
            <div class="preview-item-content">
              <h6 class="preview-subject font-weight-normal text-dark mb-1">New user registration</h6>
              <p class="font-weight-light small-text mb-0"> 2 days ago </p>
            </div>
          </a>
        </div>
      </li>
      <li class="nav-item dropdown d-none d-xl-inline-block">
        <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
		<?php if(auth()->guard("admin")->check()): ?>
          <span class="profile-text d-none d-md-inline-flex"><?php echo e(auth()->user()->name); ?></span>
		<?php endif; ?>
		<?php if(auth()->guard("sales")->check()): ?>
          <span class="profile-text d-none d-md-inline-flex"><?php echo e(Auth::guard('sales')->user()->nama_sales); ?></span>
		<?php endif; ?>
          <img class="img-xs rounded-circle" src="<?php echo e(url('assets/images/faces/face8.jpg')); ?>" alt="Profile image"> </a>
        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
          <a class="dropdown-item mt-2"><?php echo e(__('Kelola Akun')); ?></a>
            <?php if(auth()->guard("admin")->check()): ?>
             <a href="<?php echo e(route('AdminChangePassword')); ?>" class="dropdown-item"> <?php echo e(__('Ubah Password')); ?> </a>
            <?php endif; ?>
            <?php if(auth()->guard("sales")->check()): ?>
             <a href="<?php echo e(route('SalesChangePassword')); ?>" class="dropdown-item"> <?php echo e(__('Ubah Password')); ?> </a>
            <?php endif; ?>
          <a class="dropdown-item" href="<?php echo e(url('/logout')); ?>"> <?php echo e(__('Logout')); ?> </a>
          </a>
        </div>
      </li>
    </ul>
    <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
      <span class="mdi mdi-menu icon-menu"></span>
    </button>
  </div>
</nav>
<?php /**PATH C:\xampp\htdocs\Project_1\resources\views/layout/header.blade.php ENDPATH**/ ?>